# NEGF Quantum Transport Simulator

This repository provides a transparent, research-oriented Python toolkit
for simulating quantum electron transport using the Non-Equilibrium
Green's Function (NEGF) formalism.\
It was developed to support studies on **1D tight-binding chains,
graphene-like ribbons, and CNT-like heterojunctions**, with an emphasis
on *physical interpretability* and *device-level insight*.

## Motivation & Purpose

Modern nanoelectronic devices---whether graphene nanoribbons, CNT
diodes, or engineered heterostructures---are governed by
quantum-coherent transport.\
However, most available tools are either too complicated or too opaque
for researchers who want to:

-   prototype device physics quickly,\
-   test hypotheses about band alignment or scattering,\
-   explore parameter trends before running expensive DFT simulations.

**This project was created to bridge that gap.**

It offers a clean and modifiable NEGF pipeline that makes the *cause →
effect* relation clear:\
how **onsite potentials**, **hoppings**, **geometry**, and **contact
coupling** shape **T(E)** and **I--V** behavior.

## Key Features

-   **Analytic surface Green's function** for 1D semi-infinite leads\
-   **Constructing heterojunction devices** with tunable potentials and
    hoppings\
-   **Landauer--Büttiker transport calculations**
    -   Transmission T(E)\
    -   I--V characteristics with asymmetric contacts\
-   **Parameter sweeps** for extracting device design rules\
-   **Exploration tools** for Fabry--Pérot interference, Kronig--Penney
    structures, ribbon geometry effects

## Repository Structure

    src/negf/         # Core NEGF modules
    examples/         # Toy models, CNT/GNR transport, Fabry–Perot
    figures/          # Generated plots
    data/             # CSV / numerical outputs
    notebooks/        # (Optional) workflow demos

## Getting Started

Install dependencies:

``` bash
pip install -r requirements.txt
```

Run a CNT-like heterojunction example:

``` bash
python examples/cnt_diode.py
```

This script produces:

-   `TE_spectrum.png`, `TE_spectrum.csv`
-   `IV_curve.png`, `IV_curve.csv`

## What You Can Learn

With small code changes, users can explore:

-   band-edge shifts from onsite potentials\
-   Fabry--Pérot oscillations from multi-cell interference\
-   effect of coupling strength on absolute current\
-   rectification mechanisms in heterojunction structures\
-   dephasing-induced broadening of resonances

## Background

This toolkit originated from an undergraduate research project on
quantum transport and rectification in CNT-like systems.\
It is now organized into a reusable form for future research, figure
generation, and graduate-level study.
